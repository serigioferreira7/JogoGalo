import java.util.Arrays;
import java.util.Scanner;

public class JogoDaVelha {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char[][] tabuleiro = new char[3][3];
        char jogadorAtual = 'X';
        boolean jogoAcabou = false;
        for (int i = 0; i < 3; i++) {
            Arrays.fill(tabuleiro[i], ' ');
        }
        while (!jogoAcabou) {
            System.out.println("  0 1 2");
            for (int i = 0; i < 3; i++) {
                System.out.print(i + " ");
                for (int j = 0; j < 3; j++) {
                    System.out.print(tabuleiro[i][j] + " ");
                }
                System.out.println();
            }
            System.out.println("Jogador " + jogadorAtual + ", faça sua jogada (linha coluna):");
            int linha = scanner.nextInt();
            int coluna = scanner.nextInt();
            if (linha < 0 || linha > 2 || coluna < 0 || coluna > 2) {
                System.out.println("Jogada inválida, tente novamente.");
                continue;
            }
            if (tabuleiro[linha][coluna] != ' ') {
                System.out.println("Jogada inválida, tente novamente.");
                continue;
            }


            tabuleiro[linha][coluna] = jogadorAtual;


            jogoAcabou = verificaFimDeJogo(tabuleiro);


            jogadorAtual = jogadorAtual == 'X' ? 'O' : 'X';
        }
        System.out.println("  0 1 2");
        for (int i = 0; i < 3; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 3; j++) {
                System.out.print(tabuleiro[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Jogo acabou! O jogador " + (jogadorAtual == 'X' ? 'O' : 'X') + " venceu!");
    }

    private static boolean verificaFimDeJogo(char[][] tabuleiro) {
        for (int i = 0; i < 3; i++) {
            if (tabuleiro[i][0] != ' ' && tabuleiro[i][0] == tabuleiro[i][1] && tabuleiro[i][1] == tabuleiro[i][2]) {
                return true;
            }
        }
        for (int j = 0; j < 3; j++) {
            if (tabuleiro[0][j] != ' ' && tabuleiro[0][j] == tabuleiro[1][j] && tabuleiro[1][j] == tabuleiro[2][j]) {
                return true;
            }
        }
        if (tabuleiro[0][0] != ' ' && tabuleiro[0][0] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][2]) {
            return true;
        }
        if (tabuleiro[0][2] != ' ' && tabuleiro[0][2] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][0]) {
            return true;
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tabuleiro[i][j] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }
}